<?php
$servername="localhost";
$username="root";
$password="";
$database="userdb";
$conn=mysqli_connect($servername,$username,$password,$database);
if(!$conn)
{
    echo die(mysqli_error($conn));

}

?>
